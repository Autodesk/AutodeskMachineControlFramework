import{l as o,a as r}from"../chunks/k-Mj_AwG.js";export{o as load_css,r as start};
