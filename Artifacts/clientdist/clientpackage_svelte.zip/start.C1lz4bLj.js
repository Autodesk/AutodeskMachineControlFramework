import{l as o,a as r}from"../chunks/Cu5dmR6J.js";export{o as load_css,r as start};
